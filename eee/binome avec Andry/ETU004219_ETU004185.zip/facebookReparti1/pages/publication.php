<?php
ini_set("display_errors","1");

include('../inc/base.php');
// include('../inc/fonction.php');

session_start();
// echo $_SESSION['id1'];
$join = "SELECT * FROM membres AS m JOIN publications AS p ON m.ID_Membre = p.ID_Membre ORDER BY p.Date_pub DESC ";
// $join = "SELECT * FROM publications AS p JOIN bloquer as b ORDER BY p.Date_pub DESC  where p.ID_Membre is not b.ID_Membre2";

// $join = "SELECT * FROM membres AS m JOIN publications AS p JOIN bloquer as b ON m.ID_Membre = p.ID_Membre ORDER BY p.Date_pub DESC where p.ID_Membre is not b.ID_Membre2";
// $join = "SELECT * FROM membres AS m JOIN publications AS p ON m.ID_Membre = p.ID_Membre JOIN amis AS a ON p.ID_Membre = a.ID_Membre2 ORDER BY p.Date_pub DESC";
$query1 = mysqli_query($bdd, $join);
// echo $query1;
$_SESSION['query1'] = $query1;


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualite</title>
    <link rel="stylesheet" href="../asset/css/style1.css">
</head>

<body>
    <div class="profil_container">
        <h4> Commencer a publier </h4>
        <form action="traitement_pub.php" method="post">
            <p><input class="form" type="text" name="pub" id="pub" placeholder="Votre texte ici" required></p>
            <p><input class="form_sub" type="submit" value="Publier"></p>
        </form>
        <a href="home.php"><input type="button" value="Revenir"></a>
        
        <div class="list-pub">
                <?php if( $query1 ){ ?>          
                <?php while ($_SESSION['list_pub'] = mysqli_fetch_assoc($query1) ) { ?>
                    <div class="publication">
                        <h5><?php echo $_SESSION['list_pub']['Nom']; ?></h5>
                        <h5><?php echo $_SESSION['list_pub']['Date_pub']; ?></h5>
                        <p><?php echo $_SESSION['list_pub']['Contenu']; ?></p>
                    </div>
                    
                    <a href="commentaire.php?id_pub=<?php echo $_SESSION['list_pub']['ID_Pub']; ?>"><input type="button" value="Voir plus..."></a>
                <?php } ?>
                <?php } ?>
        </div>
        <a href="traitement_logout.php"><input class="form_sub" type="button" value="Se deconnecter"></a>
    </div>

</body>
</html>