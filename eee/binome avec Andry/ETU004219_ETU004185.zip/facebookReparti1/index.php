<?php
    header("location: pages/index.php");
?>
