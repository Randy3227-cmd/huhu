CREATE TABLE membres (
    ID_Membre INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(100),
    Nom VARCHAR(100),
    Mot_de_passe VARCHAR(100),
    Date_naissance DATE
);

CREATE TABLE publications (
    ID_Pub INT PRIMARY KEY AUTO_INCREMENT,
    Date_pub DATETIME,
    Contenu TEXT,
    ID_Membre INT
   
);

CREATE TABLE commentaire (
    ID_Commentaire INT PRIMARY KEY AUTO_INCREMENT,
    ID_Pub INT,
    Date_coms DATETIME,
    TexteComs TEXT,
    ID_Membre INT
);

CREATE TABLE amis (
    ID_Membre1 INT,
    ID_Membre2 INT,
    DateHeureDemande DATETIME,
    DateHeureAcceptation DATETIME
);

CREATE TABLE bloquer(
    ID_Membre1 INT ,
    ID_Membre2 INT
);



