<?php
    $bdd = mysqli_connect('localhost', 'root', '', 'facebook');
?>