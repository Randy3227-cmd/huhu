<?php 
 
    ini_set("display_errors","1");

    function inscription($email,$nom,$mdp, $date_nais){
        include('base.php');
        $insert = "INSERT INTO membres (email, Nom, Mot_de_passe, Date_naissance) VALUES ('%s','%s','%s','%s')";
        $query = sprintf($insert,$email,$nom,$mdp,$date_nais);
        mysqli_query($bdd, $query);
    }


    function login ($email,$mdp){
        include('base.php');
        $query = "SELECT * FROM membres WHERE email = '%s' AND Mot_de_passe = '%s'";
        $sql = sprintf($query, $email, $mdp);
        $result= mysqli_query($bdd,$sql);
        return $result;
    }

    

    function insererCommentaire ($texte ,$id_pub ,  $date ,$idmembre){
        include('base.php');
        $insert = "INSERT INTO commentaire (ID_Pub, Date_coms, TexteComs, ID_Membre) VALUES ('%s','%s','%s','%s')";
        $query = sprintf($insert, $id_pub, $date, $texte, $idmembre);
        mysqli_query($bdd, $query);
    }


    function insererPub($texte,$date, $idmembre){
        include('base.php');
        $insert = "INSERT INTO publications (Date_pub, Contenu , ID_Membre) VALUES ('%s','%s','%s')";
        $query = sprintf($insert,$date,$texte,$idmembre);    
        $donne = mysqli_query($bdd, $query);
        return $donne;
    }

    function blocker($id1,$id2){
        include('base.php');
        $sql = "INSERT INTO bloquer VALUES ($id1,$id2)";
        $query = mysqli_query($bdd,$sql);
    }
    function showMembreFB(){
        session_start();
        include('base.php');
        
        $idConnecte = $_SESSION['afficher']['ID_Membre'];
        $sql = "SELECT * FROM membres WHERE ID_Membre <> (%s) ";
        $sql = sprintf($sql,$_SESSION['afficher']['ID_Membre']);
        $query = mysqli_query($bdd,$sql);
        $_SESSION['AfficheMembreQuery'] = $query;
    }


    function Accepter ($id1,$id2){
        include('base.php');    
        $sql = sprintf("UPDATE amis SET DateHeureAcceptation = NOW() WHERE ID_Membre1 = '%s' AND ID_Membre2 = '%s'", $id1,$id2);
        $sql = mysqli_query($bdd,$sql);

    }

    
    function Ajouter ($id1, $id2){
        include('base.php');
        $sql = sprintf("INSERT INTO amis (ID_Membre1,ID_Membre2,DateHeureDemande) VALUES ('%s','%s',NOW())" , $id1, $id2);
        $sql = mysqli_query($bdd, $sql);

    }

    
    function Refuser($id1,$id2){
        include('base.php');
    
        $sql=sprintf("DELETE FROM amis WHERE ID_Membre1='%s' AND ID_Membre2='%s' AND DateHeureAcceptation IS NULL",$id2,$id1);
        mysqli_query($bdd,$sql);
    }


    function findFriends($id1, $id2, $dtDemande, $dtAccept) {
        if ($dtAccept != NULL && $dtDemande != NULL) {
            return "Ami(e)";
        } elseif ($dtDemande != NULL && $dtAccept == NULL) {
            return "Accepter";
        } else {
            Ajouter($id1, $id2);
            return "Ajouter";
        }
    }


    function supprimer($id1,$id2){
        include('base.php');
    
        $sql=sprintf("DELETE FROM amis WHERE ID_Membre1='%s' AND ID_Membre2='%s' AND DateHeureAcceptation IS NOT NULL",$id1,$id2);
        mysqli_query($bdd,$sql);
    }


    function sontAmis($utilisateur1, $utilisateur2) {
        include('base.php');    

        $phrase='Ajouter comme ami(e)';
        
        $requete = "SELECT * FROM amis WHERE
         ((ID_Membre1 = '$utilisateur1' AND ID_Membre2 = '$utilisateur2')
         AND (DateHeureDemande is not null)
         AND (DateHeureAcceptation is null))";
    
        $requete1 = "SELECT * FROM amis WHERE
             ((ID_Membre1 = '$utilisateur2' AND ID_Membre2 = '$utilisateur1')
          AND (DateHeureDemande is not null)
          AND (DateHeureAcceptation is null))";
    
        $requete2="SELECT * FROM amis WHERE
          ((ID_Membre1 = '$utilisateur2' AND ID_Membre2 = '$utilisateur1')
          OR (ID_Membre1 = '$utilisateur1' AND ID_Membre2 = '$utilisateur2'))
          AND ((DateHeureDemande is null)
          AND (DateHeureAcceptation is not null))";
    
        $resultat = mysqli_query($bdd, $requete);
        $resultat1=mysqli_query($bdd,$requete1);
        $resultat2=mysqli_query($bdd,$requete2);   
            
            if (mysqli_num_rows($resultat) > 0) {
                    $phrase='Demande envoyée'; 
            }
            if(mysqli_num_rows($resultat1) > 0)
            {
                $phrase='Confirmer';
            }
            if(mysqli_num_rows($resultat2) > 0)
            {
                $phrase='Ami(e)';
            }

            return $phrase;
    }
    

?>